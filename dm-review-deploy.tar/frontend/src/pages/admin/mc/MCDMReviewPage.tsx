import { useEffect, useMemo, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import AdminLayout from '../../../layouts/AdminLayout';
import { GlassCard } from '../../../components/mc/GlassCard';
import {
  useCreateDmReviewJob,
  useDmReviewConfig,
  useDmReviewFinding,
  useDmReviewFindings,
  useDmReviewRun,
  useDmReviewRuns,
  useLaunchDmReviewJarvis,
  useStartDmReviewRun,
  useUpdateDmReviewConfig,
} from '../../../hooks/useDmReviewApi';

const STATUS_COLORS: Record<string, string> = {
  strong: 'bg-emerald-500/15 text-emerald-300 border-emerald-500/25',
  mixed: 'bg-sky-500/15 text-sky-300 border-sky-500/25',
  weak: 'bg-amber-500/15 text-amber-300 border-amber-500/25',
  critical: 'bg-red-500/15 text-red-300 border-red-500/25',
  queued: 'bg-gray-500/15 text-gray-300 border-gray-500/25',
  running: 'bg-blue-500/15 text-blue-300 border-blue-500/25',
  completed: 'bg-emerald-500/15 text-emerald-300 border-emerald-500/25',
  failed: 'bg-red-500/15 text-red-300 border-red-500/25',
};

function formatDateTime(value?: string | null): string {
  if (!value) return '-';
  return new Date(value).toLocaleString('tr-TR');
}

function formatRelative(value?: string | null): string {
  if (!value) return '-';
  const diffMs = Date.now() - new Date(value).getTime();
  const mins = Math.floor(diffMs / 60000);
  if (mins < 1) return 'az once';
  if (mins < 60) return `${mins}dk once`;
  const hours = Math.floor(mins / 60);
  if (hours < 24) return `${hours}sa once`;
  return `${Math.floor(hours / 24)}g once`;
}

function SummaryMetric({ label, value, hint }: { label: string; value: string; hint?: string }) {
  return (
    <GlassCard className="p-4" hover={false}>
      <div className="text-[11px] uppercase tracking-[0.2em] text-gray-500">{label}</div>
      <div className="mt-2 text-2xl font-semibold text-gray-100">{value}</div>
      {hint ? <div className="mt-1 text-xs text-gray-400">{hint}</div> : null}
    </GlassCard>
  );
}

export default function MCDMReviewPage() {
  const navigate = useNavigate();
  const configQuery = useDmReviewConfig();
  const runsQuery = useDmReviewRuns(25);
  const [selectedRunId, setSelectedRunId] = useState<string | null>(null);
  const [selectedFindingId, setSelectedFindingId] = useState<string | null>(null);
  const [daysBack, setDaysBack] = useState(7);
  const [model, setModel] = useState('openai/gpt-4.1');
  const [maxThreadsPerRun, setMaxThreadsPerRun] = useState(80);
  const [statusFilter, setStatusFilter] = useState('');
  const [flagFilter, setFlagFilter] = useState('');
  const [customerFilter, setCustomerFilter] = useState('');
  const [unresolvedOnly, setUnresolvedOnly] = useState(false);
  const [hallucinationOnly, setHallucinationOnly] = useState(false);
  const [repetitiveOnly, setRepetitiveOnly] = useState(false);
  const [actionMessage, setActionMessage] = useState<string | null>(null);

  const selectedRunFromList = useMemo(
    () => runsQuery.data?.runs.find(run => run.id === selectedRunId) || runsQuery.data?.runs[0] || null,
    [runsQuery.data?.runs, selectedRunId],
  );
  const runPollMs = selectedRunFromList?.status === 'queued' || selectedRunFromList?.status === 'running' ? 4000 : 0;
  const runQuery = useDmReviewRun(selectedRunId || selectedRunFromList?.id || null, runPollMs);
  const activeRun = runQuery.data || selectedRunFromList || null;
  const findingsQuery = useDmReviewFindings(activeRun?.id || null, {
    status: statusFilter || undefined,
    customerId: customerFilter || undefined,
    flag: flagFilter || undefined,
    unresolvedOnly,
    hallucinationOnly,
    repetitiveOnly,
    limit: 200,
  }, runPollMs);
  const selectedFinding = useDmReviewFinding(activeRun?.id || null, selectedFindingId);

  const startRun = useStartDmReviewRun();
  const updateConfig = useUpdateDmReviewConfig();
  const createJob = useCreateDmReviewJob();
  const launchJarvis = useLaunchDmReviewJarvis();

  useEffect(() => {
    if (configQuery.data) {
      setDaysBack(configQuery.data.daysBack);
      setModel(configQuery.data.model);
      setMaxThreadsPerRun(configQuery.data.maxThreadsPerRun);
    }
  }, [configQuery.data]);

  useEffect(() => {
    if (!selectedRunId && runsQuery.data?.runs?.length) {
      setSelectedRunId(runsQuery.data.runs[0].id);
    }
  }, [runsQuery.data?.runs, selectedRunId]);

  useEffect(() => {
    const firstFinding = findingsQuery.data?.findings?.[0];
    if (!selectedFindingId && firstFinding) {
      setSelectedFindingId(firstFinding.id);
    }
    if (selectedFindingId && findingsQuery.data?.findings && !findingsQuery.data.findings.some(finding => finding.id === selectedFindingId)) {
      setSelectedFindingId(firstFinding?.id || null);
    }
  }, [findingsQuery.data?.findings, selectedFindingId]);

  const summary = activeRun?.summary || {};
  const scoreAverages = summary.scoreAverages || {};
  const topFlags = Array.isArray(summary.topFlags) ? summary.topFlags : [];
  const topNeeds = Array.isArray(summary.topNeeds) ? summary.topNeeds : [];
  const recommendations = Array.isArray(summary.recommendations) ? summary.recommendations : [];

  const handleStartRun = async () => {
    try {
      setActionMessage(null);
      const result = await startRun.mutateAsync({
        daysBack,
        model,
        maxThreadsPerRun,
        channel: 'instagram',
      });
      setSelectedRunId(result.runId);
      setSelectedFindingId(null);
      setActionMessage(`Run baslatildi: ${result.runId}`);
    } catch (error: any) {
      setActionMessage(error?.response?.data?.error || 'Run baslatilamadi.');
    }
  };

  const handleSaveDefaults = async () => {
    try {
      setActionMessage(null);
      await updateConfig.mutateAsync({
        daysBack,
        model,
        maxThreadsPerRun,
      });
      setActionMessage('Varsayilan DM review ayarlari kaydedildi.');
    } catch (error: any) {
      setActionMessage(error?.response?.data?.error || 'Ayarlar kaydedilemedi.');
    }
  };

  const handleLaunchJarvis = async () => {
    if (!activeRun?.id) return;
    try {
      setActionMessage(null);
      const result = await launchJarvis.mutateAsync(activeRun.id);
      setActionMessage(result.message || `Jarvis oturumu acildi: ${result.sessionId}`);
      navigate('/admin/mc/jarvis');
    } catch (error: any) {
      setActionMessage(error?.response?.data?.error || 'Jarvis review baslatilamadi.');
    }
  };

  const handleCreateJob = async () => {
    const findingId = selectedFinding.data?.id || selectedFindingId;
    if (!findingId) return;
    try {
      setActionMessage(null);
      const result = await createJob.mutateAsync({ findingId, priority: 'medium' });
      setActionMessage(`Forge / Workshop isi olustu: ${result.job.title}`);
    } catch (error: any) {
      setActionMessage(error?.response?.data?.error || 'Is olusturulamadi.');
    }
  };

  return (
    <AdminLayout>
      <div className="space-y-6">
        <div className="mc-page-header mc-fade-up">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-cyan-500/10 border border-cyan-500/20 flex items-center justify-center">
              <span className="text-base">DM</span>
            </div>
            <div>
              <h1 className="mc-page-title">DM Review</h1>
              <p className="text-sm text-gray-400">Kayitli thread review runlari, bulgular ve iyilestirme sinyalleri.</p>
            </div>
          </div>
          <div className="flex flex-wrap gap-2">
            <button
              onClick={handleSaveDefaults}
              disabled={updateConfig.isPending}
              className="px-3 py-2 rounded-lg border border-white/10 text-sm text-gray-200 hover:bg-white/5 disabled:opacity-60"
            >
              Varsayilanlari Kaydet
            </button>
            <button
              onClick={handleStartRun}
              disabled={startRun.isPending}
              className="px-4 py-2 rounded-lg bg-cyan-500/20 border border-cyan-500/30 text-sm font-medium text-cyan-200 hover:bg-cyan-500/30 disabled:opacity-60"
            >
              {startRun.isPending ? 'Baslatiliyor...' : 'Run Baslat'}
            </button>
          </div>
        </div>

        <GlassCard className="p-5" hover={false}>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <label className="block">
              <span className="text-xs uppercase tracking-[0.18em] text-gray-500">Days Back</span>
              <input
                type="number"
                min={1}
                max={30}
                value={daysBack}
                onChange={(event) => setDaysBack(Number(event.target.value))}
                className="mt-2 w-full rounded-lg bg-slate-900/60 border border-white/10 px-3 py-2 text-sm text-gray-100"
              />
            </label>
            <label className="block">
              <span className="text-xs uppercase tracking-[0.18em] text-gray-500">Model</span>
              <input
                type="text"
                value={model}
                onChange={(event) => setModel(event.target.value)}
                className="mt-2 w-full rounded-lg bg-slate-900/60 border border-white/10 px-3 py-2 text-sm text-gray-100"
              />
            </label>
            <label className="block">
              <span className="text-xs uppercase tracking-[0.18em] text-gray-500">Max Threads</span>
              <input
                type="number"
                min={1}
                max={300}
                value={maxThreadsPerRun}
                onChange={(event) => setMaxThreadsPerRun(Number(event.target.value))}
                className="mt-2 w-full rounded-lg bg-slate-900/60 border border-white/10 px-3 py-2 text-sm text-gray-100"
              />
            </label>
          </div>
          {actionMessage ? <div className="mt-4 text-sm text-cyan-200">{actionMessage}</div> : null}
        </GlassCard>

        <div className="grid grid-cols-1 xl:grid-cols-[280px_minmax(0,1fr)] gap-5">
          <GlassCard className="p-4 h-fit" hover={false}>
            <div className="flex items-center justify-between mb-3">
              <div className="text-sm font-semibold text-gray-100">Run History</div>
              <div className="text-xs text-gray-500">{runsQuery.data?.runs.length || 0} run</div>
            </div>
            <div className="space-y-2 max-h-[700px] overflow-auto">
              {runsQuery.data?.runs.map((run) => (
                <button
                  key={run.id}
                  onClick={() => {
                    setSelectedRunId(run.id);
                    setSelectedFindingId(null);
                  }}
                  className={`w-full text-left rounded-xl border px-3 py-3 transition-colors ${
                    activeRun?.id === run.id
                      ? 'border-cyan-500/40 bg-cyan-500/10'
                      : 'border-white/10 bg-white/[0.02] hover:bg-white/[0.05]'
                  }`}
                >
                  <div className="flex items-center justify-between gap-3">
                    <span className="text-sm font-medium text-gray-100 truncate">{run.id.slice(0, 8)}</span>
                    <span className={`text-[10px] px-2 py-0.5 rounded-full border ${STATUS_COLORS[run.status] || STATUS_COLORS.queued}`}>
                      {run.status}
                    </span>
                  </div>
                  <div className="mt-2 text-xs text-gray-400">{run.totalThreads} thread · {run.totalMessages} mesaj</div>
                  <div className="mt-1 text-xs text-gray-500">{formatRelative(run.createdAt)}</div>
                  {run.progressMessage ? <div className="mt-1 text-[11px] text-cyan-200">{run.progressMessage}</div> : null}
                </button>
              ))}
            </div>
          </GlassCard>

          <div className="space-y-5">
            <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-5 gap-4">
              <SummaryMetric label="Quality" value={`${((Number(scoreAverages.accuracy || 0) + Number(scoreAverages.helpfulness || 0) + Number(scoreAverages.tone || 0) + Number(scoreAverages.efficiency || 0) + Number(scoreAverages.intentCapture || 0)) / 5 || 0).toFixed(1)}/10`} hint={activeRun?.summary?.summary || 'Run summary'} />
              <SummaryMetric label="Threads" value={String(activeRun?.totalThreads || 0)} hint={`${activeRun?.reviewedThreads || 0} reviewed`} />
              <SummaryMetric label="Hallucination" value={String(activeRun?.summary?.hallucinationRiskThreads || 0)} hint="risk threads" />
              <SummaryMetric label="Repetition" value={String(activeRun?.summary?.repetitiveThreads || 0)} hint="repetitive threads" />
              <SummaryMetric label="Needs" value={String(topNeeds.length)} hint={topNeeds.slice(0, 2).join(', ') || 'No summary'} />
            </div>

            <GlassCard className="p-5" hover={false}>
              <div className="flex flex-wrap items-center justify-between gap-3">
                <div>
                  <div className="text-sm font-semibold text-gray-100">Run Detail</div>
                  <div className="text-xs text-gray-400 mt-1">
                    {activeRun ? `${activeRun.id} · ${formatDateTime(activeRun.createdAt)} · ${activeRun.model}` : 'Run secilmedi'}
                  </div>
                </div>
                <div className="flex flex-wrap gap-2">
                  <button
                    onClick={handleLaunchJarvis}
                    disabled={!activeRun || activeRun.status !== 'completed' || launchJarvis.isPending}
                    className="px-3 py-2 rounded-lg border border-white/10 text-sm text-gray-100 hover:bg-white/5 disabled:opacity-50"
                  >
                    {launchJarvis.isPending ? 'Jarvis...' : 'Jarvis Review'}
                  </button>
                </div>
              </div>

              <div className="mt-4 grid grid-cols-1 lg:grid-cols-3 gap-4">
                <div className="lg:col-span-2 space-y-3">
                  <div className="text-sm text-gray-200">{activeRun?.summary?.summary || activeRun?.progressMessage || 'Run ozeti henuz yok.'}</div>
                  <div className="grid grid-cols-2 gap-3">
                    <div className="rounded-xl border border-white/10 bg-white/[0.02] p-3">
                      <div className="text-xs uppercase tracking-[0.18em] text-gray-500">Top Flags</div>
                      <div className="mt-2 flex flex-wrap gap-2">
                        {topFlags.length ? topFlags.map((flag: string) => (
                          <span key={flag} className="text-xs px-2 py-1 rounded-full border border-amber-500/20 bg-amber-500/10 text-amber-200">{flag}</span>
                        )) : <span className="text-xs text-gray-500">Yok</span>}
                      </div>
                    </div>
                    <div className="rounded-xl border border-white/10 bg-white/[0.02] p-3">
                      <div className="text-xs uppercase tracking-[0.18em] text-gray-500">Top Needs</div>
                      <div className="mt-2 flex flex-wrap gap-2">
                        {topNeeds.length ? topNeeds.map((need: string) => (
                          <span key={need} className="text-xs px-2 py-1 rounded-full border border-cyan-500/20 bg-cyan-500/10 text-cyan-200">{need}</span>
                        )) : <span className="text-xs text-gray-500">Yok</span>}
                      </div>
                    </div>
                  </div>
                </div>
                <div className="rounded-xl border border-white/10 bg-white/[0.02] p-3">
                  <div className="text-xs uppercase tracking-[0.18em] text-gray-500">Recommendations</div>
                  <div className="mt-2 space-y-2">
                    {recommendations.length ? recommendations.map((rec: string) => (
                      <div key={rec} className="text-sm text-gray-200">{rec}</div>
                    )) : <div className="text-sm text-gray-500">Oneri yok.</div>}
                  </div>
                </div>
              </div>
            </GlassCard>

            <div className="grid grid-cols-1 xl:grid-cols-[minmax(0,1.2fr)_minmax(340px,0.8fr)] gap-5">
              <GlassCard className="p-5" hover={false}>
                <div className="flex flex-wrap items-center justify-between gap-3 mb-4">
                  <div>
                    <div className="text-sm font-semibold text-gray-100">Findings</div>
                    <div className="text-xs text-gray-400 mt-1">{findingsQuery.data?.findings.length || 0} finding</div>
                  </div>
                  <div className="flex flex-wrap gap-2">
                    <select value={statusFilter} onChange={(event) => setStatusFilter(event.target.value)} className="rounded-lg bg-slate-900/60 border border-white/10 px-3 py-2 text-sm text-gray-100">
                      <option value="">Tum statusler</option>
                      <option value="critical">Critical</option>
                      <option value="weak">Weak</option>
                      <option value="mixed">Mixed</option>
                      <option value="strong">Strong</option>
                    </select>
                    <input value={flagFilter} onChange={(event) => setFlagFilter(event.target.value)} placeholder="Flag ara" className="rounded-lg bg-slate-900/60 border border-white/10 px-3 py-2 text-sm text-gray-100" />
                    <input value={customerFilter} onChange={(event) => setCustomerFilter(event.target.value)} placeholder="Customer id" className="rounded-lg bg-slate-900/60 border border-white/10 px-3 py-2 text-sm text-gray-100" />
                  </div>
                </div>
                <div className="flex flex-wrap gap-2 mb-4">
                  <button onClick={() => setUnresolvedOnly(!unresolvedOnly)} className={`px-3 py-1.5 rounded-full border text-xs ${unresolvedOnly ? 'border-cyan-500/30 bg-cyan-500/15 text-cyan-200' : 'border-white/10 text-gray-400'}`}>Unresolved</button>
                  <button onClick={() => setHallucinationOnly(!hallucinationOnly)} className={`px-3 py-1.5 rounded-full border text-xs ${hallucinationOnly ? 'border-red-500/30 bg-red-500/15 text-red-200' : 'border-white/10 text-gray-400'}`}>Hallucination</button>
                  <button onClick={() => setRepetitiveOnly(!repetitiveOnly)} className={`px-3 py-1.5 rounded-full border text-xs ${repetitiveOnly ? 'border-amber-500/30 bg-amber-500/15 text-amber-200' : 'border-white/10 text-gray-400'}`}>Repetitive</button>
                </div>
                <div className="space-y-2 max-h-[700px] overflow-auto">
                  {findingsQuery.data?.findings.map((finding) => (
                    <button
                      key={finding.id}
                      onClick={() => setSelectedFindingId(finding.id)}
                      className={`w-full rounded-xl border px-4 py-3 text-left transition-colors ${
                        selectedFinding.data?.id === finding.id || selectedFindingId === finding.id
                          ? 'border-cyan-500/35 bg-cyan-500/10'
                          : 'border-white/10 bg-white/[0.02] hover:bg-white/[0.05]'
                      }`}
                    >
                      <div className="flex items-center justify-between gap-3">
                        <div className="min-w-0">
                          <div className="text-sm font-medium text-gray-100 truncate">{finding.customerName || finding.customerId}</div>
                          <div className="text-xs text-gray-400 mt-1">{finding.primaryNeed || 'unknown'} · {finding.messageCount} mesaj · {formatRelative(finding.startedAt)}</div>
                        </div>
                        <span className={`text-[10px] px-2 py-0.5 rounded-full border ${STATUS_COLORS[finding.overallStatus] || STATUS_COLORS.mixed}`}>
                          {finding.overallStatus}
                        </span>
                      </div>
                      <div className="mt-2 text-sm text-gray-300 line-clamp-2">{finding.review?.summary || 'Summary yok'}</div>
                      <div className="mt-2 flex flex-wrap gap-2">
                        {(finding.flags || []).slice(0, 4).map((flag) => (
                          <span key={flag} className="text-[11px] px-2 py-0.5 rounded-full border border-white/10 bg-white/[0.03] text-gray-300">{flag}</span>
                        ))}
                      </div>
                    </button>
                  ))}
                  {!findingsQuery.data?.findings?.length ? <div className="text-sm text-gray-500">Bu filtrelerle finding bulunamadi.</div> : null}
                </div>
              </GlassCard>

              <GlassCard className="p-5" hover={false}>
                <div className="flex items-start justify-between gap-3">
                  <div>
                    <div className="text-sm font-semibold text-gray-100">Finding Detail</div>
                    <div className="text-xs text-gray-400 mt-1">{selectedFinding.data?.customerId || 'Finding secilmedi'}</div>
                  </div>
                  <div className="flex gap-2">
                    {selectedFinding.data?.customerId ? (
                      <Link
                        to={`/admin/interactions?customerId=${encodeURIComponent(selectedFinding.data.customerId)}`}
                        className="px-3 py-2 rounded-lg border border-white/10 text-xs text-gray-200 hover:bg-white/5"
                      >
                        Interactions
                      </Link>
                    ) : null}
                    <button
                      onClick={handleCreateJob}
                      disabled={!selectedFinding.data || createJob.isPending}
                      className="px-3 py-2 rounded-lg border border-cyan-500/25 bg-cyan-500/10 text-xs text-cyan-200 hover:bg-cyan-500/20 disabled:opacity-50"
                    >
                      {createJob.isPending ? 'Olusuyor...' : 'Forge / Workshop Isi'}
                    </button>
                  </div>
                </div>

                {selectedFinding.data ? (
                  <div className="mt-4 space-y-4">
                    <div className="rounded-xl border border-white/10 bg-white/[0.02] p-3">
                      <div className="flex items-center justify-between gap-3">
                        <div className="text-sm font-medium text-gray-100">{selectedFinding.data.review?.summary || 'Summary yok'}</div>
                        <span className={`text-[10px] px-2 py-0.5 rounded-full border ${STATUS_COLORS[selectedFinding.data.overallStatus] || STATUS_COLORS.mixed}`}>{selectedFinding.data.overallStatus}</span>
                      </div>
                      <div className="mt-2 flex flex-wrap gap-2">
                        {(selectedFinding.data.flags || []).map((flag) => (
                          <span key={flag} className="text-[11px] px-2 py-0.5 rounded-full border border-white/10 bg-white/[0.03] text-gray-300">{flag}</span>
                        ))}
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-3">
                      <div className="rounded-xl border border-white/10 bg-white/[0.02] p-3">
                        <div className="text-xs uppercase tracking-[0.18em] text-gray-500">Scores</div>
                        <div className="mt-2 space-y-1 text-sm text-gray-200">
                          {Object.entries(selectedFinding.data.review?.scores || {}).map(([key, value]) => (
                            <div key={key} className="flex items-center justify-between gap-3">
                              <span>{key}</span>
                              <span className="font-mono">{String(value)}</span>
                            </div>
                          ))}
                        </div>
                      </div>
                      <div className="rounded-xl border border-white/10 bg-white/[0.02] p-3">
                        <div className="text-xs uppercase tracking-[0.18em] text-gray-500">Deterministic</div>
                        <div className="mt-2 space-y-1 text-sm text-gray-200">
                          <div className="flex justify-between"><span>Repeated</span><span className="font-mono">{String(selectedFinding.data.deterministicMetrics?.repeatedResponseCount || 0)}</span></div>
                          <div className="flex justify-between"><span>Closeout followups</span><span className="font-mono">{String(selectedFinding.data.deterministicMetrics?.closeoutFollowups || 0)}</span></div>
                          <div className="flex justify-between"><span>Unresolved</span><span className="font-mono">{String(selectedFinding.data.deterministicMetrics?.unresolvedQuestionCount || 0)}</span></div>
                          <div className="flex justify-between"><span>Slow simple turn</span><span className="font-mono">{selectedFinding.data.deterministicMetrics?.hasSlowSimpleTurn ? 'yes' : 'no'}</span></div>
                        </div>
                      </div>
                    </div>

                    <div className="grid grid-cols-1 gap-3">
                      <div className="rounded-xl border border-white/10 bg-white/[0.02] p-3">
                        <div className="text-xs uppercase tracking-[0.18em] text-gray-500">Suggestions</div>
                        <div className="mt-2 space-y-2">
                          {(['pipeline', 'knowledgeBase', 'tone'] as const).map((group) => (
                            <div key={group}>
                              <div className="text-[11px] uppercase tracking-[0.16em] text-gray-500">{group}</div>
                              <div className="mt-1 space-y-1">
                                {Array.isArray(selectedFinding.data.review?.suggestions?.[group]) && selectedFinding.data.review.suggestions[group].length
                                  ? selectedFinding.data.review.suggestions[group].map((item: string) => (
                                      <div key={item} className="text-sm text-gray-200">{item}</div>
                                    ))
                                  : <div className="text-sm text-gray-500">No suggestion</div>}
                              </div>
                            </div>
                          ))}
                        </div>
                      </div>

                      <div className="rounded-xl border border-white/10 bg-white/[0.02] p-3">
                        <div className="text-xs uppercase tracking-[0.18em] text-gray-500">Transcript Snapshot</div>
                        <div className="mt-2 max-h-[360px] overflow-auto space-y-2">
                          {selectedFinding.data.transcript?.messages?.map((message) => (
                            <div key={message.id} className={`rounded-lg px-3 py-2 border ${message.direction === 'inbound' ? 'border-sky-500/20 bg-sky-500/5' : 'border-violet-500/20 bg-violet-500/5'}`}>
                              <div className="flex items-center justify-between gap-3 text-[11px] text-gray-400">
                                <span>{message.direction === 'inbound' ? 'Customer' : 'Assistant'}</span>
                                <span>{formatDateTime(message.createdAt)}</span>
                              </div>
                              <div className="mt-1 text-sm text-gray-100 whitespace-pre-wrap">{message.text}</div>
                              {(message.modelUsed || message.responseTimeMs || message.intent) ? (
                                <div className="mt-1 text-[11px] text-gray-500">
                                  {[message.intent, message.modelUsed, message.responseTimeMs ? `${message.responseTimeMs}ms` : ''].filter(Boolean).join(' · ')}
                                </div>
                              ) : null}
                            </div>
                          ))}
                        </div>
                      </div>
                    </div>
                  </div>
                ) : (
                  <div className="mt-4 text-sm text-gray-500">Soldan bir finding secin.</div>
                )}
              </GlassCard>
            </div>
          </div>
        </div>
      </div>
    </AdminLayout>
  );
}
